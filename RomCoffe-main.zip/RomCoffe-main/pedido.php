<?php
session_start();
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'user') {
  $_SESSION['flash_error'] = 'Acceso denegado. Debes iniciar sesión como usuario.';
  header('Location: index.php');
  exit;
}
require_once __DIR__ . '/conexion.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tipo = $_POST['tipo_pedido'] ?? '';
  $productos = $_POST['productos'] ?? '';
  $total = (float)($_POST['total'] ?? 0);
  $uid = (int)($_SESSION['user_id'] ?? 0);

  if (!in_array($tipo, ['local', 'retirar'], true)) {
    $error = 'Tipo de pedido inválido.';
  } elseif ($productos === '' || $total <= 0 || $uid <= 0) {
    $error = 'Completa los datos del pedido.';
  } else {
    $stmt = $conn->prepare("INSERT INTO pedidos (id_usuario, tipo_pedido, productos, total) VALUES (?,?,?,?)");
    $stmt->bind_param("issd", $uid, $tipo, $productos, $total);
    if ($stmt->execute()) {
      $success = '✅ Pedido registrado con éxito';
    } else {
      $error = 'No se pudo registrar el pedido.';
    }
  }
}

// Obtener productos para mostrar
$productos = [];
$res = $conn->query("SELECT id_producto, nombre, descripcion, precio, imagen FROM productos ORDER BY id_producto DESC");
if ($res) { while ($row = $res->fetch_assoc()) { $productos[] = $row; } }
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Hacer pedido • RomCoffe</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Poppins:wght@400;600;700&family=Dancing+Script:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=2" />
  <style>
    .wrap{max-width:1200px;margin:100px auto 40px;padding:0 20px}
    .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
    .msg{margin:0 0 16px;background:#ecfdf5;border:2px solid #10b981;color:#065f46;padding:10px 12px;border-radius:12px;font-weight:600}
    .err{margin:0 0 16px;background:rgba(242,65,65,.12);border:2px solid #F24141;color:#7f1d1d;padding:10px 12px;border-radius:12px;font-weight:600}
  </style>
</head>
<body>
  <header class="main-header">
    <div class="header-content">
      <a href="index.php" class="instagram-btn"><span class="instagram-text">RomCoffe</span></a>
      <div class="instagram-btn login-btn"><span class="instagram-text">Usuario: <?= htmlspecialchars($_SESSION['username'] ?? '') ?></span></div>
    </div>
  </header>

  <div class="wrap">
    <?php if ($success): ?><div class="msg"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <h2 class="section-title">Realizar pedido</h2>
    <form id="orderForm" method="post" class="auth-form">
      <div class="group">
        <label class="auth-label">Tipo de pedido</label>
        <select class="auth-input" name="tipo_pedido" id="tipo_pedido" required>
          <option value="local">Consumir en el local</option>
          <option value="retirar">Retirar para llevar</option>
        </select>
      </div>
      <div class="group">
        <label class="auth-label">Seleccioná productos</label>
        <div class="cards">
          <?php foreach ($productos as $p): ?>
            <article class="card">
              <div class="card-media"><?php if (!empty($p['imagen'])): ?><img src="<?= htmlspecialchars($p['imagen']) ?>" alt="<?= htmlspecialchars($p['nombre']) ?>"><?php endif; ?></div>
              <div class="card-body">
                <div class="card-head">
                  <h3 class="card-title"><?= htmlspecialchars($p['nombre']) ?></h3>
                  <span class="price">$<?= number_format((float)$p['precio'],2) ?></span>
                </div>
                <p class="card-desc"><?= htmlspecialchars($p['descripcion']) ?></p>
                <div class="group">
                  <label class="auth-label">Cantidad</label>
                  <input class="auth-input qty" type="number" min="0" step="1" value="0" data-name="<?= htmlspecialchars($p['nombre']) ?>" data-price="<?= number_format((float)$p['precio'],2,'.','') ?>">
                </div>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      </div>
      <input type="hidden" name="productos" id="productosField">
      <input type="hidden" name="total" id="totalField">
      <button class="btn primary" type="submit">Confirmar pedido</button>
    </form>
  </div>

  <script>
    const form = document.getElementById('orderForm');
    form.addEventListener('submit', function(e){
      const qtyInputs = document.querySelectorAll('.qty');
      const items = [];
      let total = 0;
      qtyInputs.forEach(i => {
        const q = parseInt(i.value, 10) || 0;
        if (q > 0) {
          const name = i.getAttribute('data-name');
          const price = parseFloat(i.getAttribute('data-price')) || 0;
          items.push({ name, qty: q, price });
          total += price * q;
        }
      });
      document.getElementById('productosField').value = JSON.stringify(items);
      document.getElementById('totalField').value = total.toFixed(2);
      if (items.length === 0) {
        e.preventDefault();
        alert('Selecciona al menos un producto');
      }
    });
  </script>
</body>
</html>


