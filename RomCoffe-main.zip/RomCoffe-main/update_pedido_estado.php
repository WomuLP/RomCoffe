<?php
session_start();
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  $_SESSION['flash_error'] = 'Acceso denegado.';
  header('Location: index.php');
  exit;
}
require_once __DIR__ . '/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)($_POST['id_pedido'] ?? 0);
  $estado = $_POST['estado'] ?? 'Pendiente';
  $valid = ['Pendiente','En preparación','Listo','Entregado'];
  if ($id > 0 && in_array($estado, $valid, true)) {
    $stmt = $conn->prepare("UPDATE pedidos SET estado=? WHERE id_pedido=?");
    $stmt->bind_param("si", $estado, $id);
    $stmt->execute();
  }
}
header('Location: admin_panel.php');
exit;
?>


