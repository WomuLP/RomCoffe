<?php
session_start();
// $_SESSION expected: user_id, username, role ('admin'|'user')
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Cafetería • Menú</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Poppins:wght@400;600;700&family=Dancing+Script:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=2" />
</head>
<body>
  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div style="max-width:960px;margin:80px auto 0;background:rgba(242,65,65,.12);border:2px solid #F24141;color:#7f1d1d;padding:10px 12px;border-radius:12px;font-weight:600;">
      <?= htmlspecialchars($_SESSION['flash_error']); unset($_SESSION['flash_error']); ?>
    </div>
  <?php endif; ?>

  <div class="main-container">
    <!-- Banner Section -->
    <section class="banner-section">
      <img class="banner" src="Banner.png" alt="Banner cafetería" />
    </section>

    <!-- Header with Navigation -->
    <header class="main-header">
      <div class="header-content">
        <a href="https://instagram.com/tu_perfil" target="_blank" class="instagram-btn">
          <span class="instagram-text">Instagram</span>
        </a>
        <?php if (!empty($_SESSION['role'])): ?>
          <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="admin_panel.php" class="instagram-btn login-btn"><span class="instagram-text">Panel de Administración</span></a>
          <?php else: ?>
            <a href="pedido.php" class="instagram-btn login-btn"><span class="instagram-text">Hacer pedido</span></a>
          <?php endif; ?>
        <?php else: ?>
          <a href="login.html" class="instagram-btn login-btn"><span class="instagram-text">Inicio de sesión</span></a>
        <?php endif; ?>
      </div>
    </header>

    <!-- Featured Carousel -->
    <section class="nc-section">
      <div class="nc-container">
        <input type="radio" name="nc-slider" id="item-1" checked>
        <input type="radio" name="nc-slider" id="item-2">
        <input type="radio" name="nc-slider" id="item-3">
        <div class="nc-cards">
          <label class="nc-card" for="item-1" id="nc-card-1">
            <img src="Destacado 2.png" alt="Slide 1">
          </label>
          <label class="nc-card" for="item-2" id="nc-card-2">
            <img src="Destacado 1.png" alt="Slide 2">
          </label>
          <label class="nc-card" for="item-3" id="nc-card-3">
            <img src="Destacado 3.png" alt="Slide 3">
          </label>
        </div>
      </div>
    </section>

    <!-- Category Filter Menu -->
    <nav class="category-menu">
      <button class="chip active" data-category="all">todos</button>
      <button class="chip" data-category="cafe">café</button>
      <button class="chip" data-category="tes">tés</button>
      <button class="chip" data-category="bebidas-frias">bebidas frías</button>
      <button class="chip" data-category="desayuno">desayuno</button>
      <button class="chip" data-category="almuerzo">almuerzo</button>
      <button class="chip" data-category="postres">postres</button>
    </nav>

    <!-- Main Content -->
    <main>
      <section class="products" id="productos">
        <h2 class="section-title">Productos</h2>
        <div class="product-grid" id="productGrid"></div>
      </section>
    </main>

    <!-- Footer -->
    <footer class="site-footer">
      <div class="footer-inner">
        <div class="footer-col">
          <h3 class="footer-brand">RomCoffe</h3>
          <p>Hecho con amor para servir excelente café y buena vibra.</p>
        </div>
        <nav class="footer-col">
          <h4>Info</h4>
          <ul class="footer-links">
            <li><a href="#">Home</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Portfolio</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
        <nav class="footer-col">
          <h4>Legal</h4>
          <ul class="footer-links">
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms &amp; Conditions</a></li>
          </ul>
        </nav>
        <div class="footer-col align-end">
          <a class="btn contact" href="#">Contactar</a>
        </div>
      </div>
      <div class="footer-bottom">© <span id="currentYear"></span> RomCoffe. Todos los derechos reservados.</div>
    </footer>

  </div>

  <script>
    document.getElementById('currentYear').textContent = new Date().getFullYear();
    // Cargar productos desde producto.php si existiera un endpoint JSON; placeholder deja contenedor vacío
  </script>
</body>

</html>


