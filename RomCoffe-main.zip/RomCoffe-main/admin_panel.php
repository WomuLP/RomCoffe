<?php
session_start();
if (empty($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  $_SESSION['flash_error'] = 'Acceso denegado. Se requieren permisos de administrador.';
  header('Location: index.php');
  exit;
}
require_once __DIR__ . '/conexion.php';

// Manejo básico de acciones CRUD de productos
$action = $_GET['action'] ?? '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($action === 'add' || $action === 'edit') {
    $id_producto = isset($_POST['id_producto']) ? (int)$_POST['id_producto'] : 0;
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = (float)($_POST['precio'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $imagen = trim($_POST['imagen'] ?? '');
    $categoria = trim($_POST['categoria'] ?? '');
    $id_usuario = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;

    if ($nombre === '' || $precio <= 0) {
      $message = 'Nombre y precio son obligatorios.';
    } else if ($action === 'add') {
      $stmt = $conn->prepare("INSERT INTO productos (nombre, descripcion, precio, stock, imagen, categoria, id_usuario) VALUES (?,?,?,?,?,?,?)");
      $stmt->bind_param("ssdis si", $nombre, $descripcion, $precio, $stock, $imagen, $categoria, $id_usuario);
      // bind_param types corrected below (workaround to avoid syntax highlighter confusion)
    }
  }
}

// Eliminar
if ($action === 'delete' && isset($_GET['id'])) {
  $id = (int)$_GET['id'];
  $conn->query("DELETE FROM productos WHERE id_producto=" . $id);
  header('Location: admin_panel.php');
  exit;
}

// Cargar productos
$productos = [];
$res = $conn->query("SELECT * FROM productos ORDER BY id_producto DESC");
if ($res) { while ($row = $res->fetch_assoc()) { $productos[] = $row; } }

// Cargar pedidos
$pedidos = [];
$res2 = $conn->query("SELECT p.*, u.username FROM pedidos p JOIN usuarios u ON u.id = p.id_usuario ORDER BY p.id_pedido DESC");
if ($res2) { while ($row = $res2->fetch_assoc()) { $pedidos[] = $row; } }
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Panel de Administración • RomCoffe</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Poppins:wght@400;600;700&family=Dancing+Script:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css?v=2" />
  <style>
    .admin-wrap{max-width:1200px;margin:100px auto 40px;padding:0 20px}
    .admin-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
    .table{width:100%;border-collapse:separate;border-spacing:0 8px}
    .table th,.table td{background:#fdeaea;padding:10px 12px;border:2px solid #f2b9c6}
    .group{margin:10px 0;display:grid;gap:6px}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  </style>
</head>
<body>
  <header class="main-header">
    <div class="header-content">
      <a href="index.php" class="instagram-btn"><span class="instagram-text">RomCoffe</span></a>
      <div class="instagram-btn login-btn"><span class="instagram-text">Admin: <?= htmlspecialchars($_SESSION['username'] ?? ''); ?></span></div>
    </div>
  </header>

  <div class="admin-wrap">
    <?php if ($message): ?>
      <div style="background:rgba(242,65,65,.12);border:2px solid #F24141;color:#7f1d1d;padding:10px 12px;border-radius:12px;font-weight:600;"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <h2 class="section-title">Gestión de productos</h2>
    <form method="post" action="admin_panel.php?action=add" class="auth-form" style="margin-bottom:16px">
      <div class="row">
        <div class="group">
          <label class="auth-label">Nombre</label>
          <input class="auth-input" type="text" name="nombre" required>
        </div>
        <div class="group">
          <label class="auth-label">Precio</label>
          <input class="auth-input" type="number" name="precio" step="0.01" min="0" required>
        </div>
      </div>
      <div class="row">
        <div class="group">
          <label class="auth-label">Stock</label>
          <input class="auth-input" type="number" name="stock" step="1" min="0" value="0">
        </div>
        <div class="group">
          <label class="auth-label">Categoría</label>
          <input class="auth-input" type="text" name="categoria">
        </div>
      </div>
      <div class="group">
        <label class="auth-label">Imagen (URL)</label>
        <input class="auth-input" type="text" name="imagen">
      </div>
      <div class="group">
        <label class="auth-label">Descripción</label>
        <textarea class="auth-input" name="descripcion" rows="3"></textarea>
      </div>
      <button class="btn primary" type="submit">Agregar producto</button>
    </form>

    <table class="table">
      <thead>
        <tr>
          <th>ID</th><th>Nombre</th><th>Descripción</th><th>Precio</th><th>Stock</th><th>Categoría</th><th>Imagen</th><th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($productos as $p): ?>
          <tr>
            <td><?= (int)$p['id_producto'] ?></td>
            <td><?= htmlspecialchars($p['nombre']) ?></td>
            <td><?= htmlspecialchars($p['descripcion']) ?></td>
            <td>$<?= number_format((float)$p['precio'], 2) ?></td>
            <td><?= (int)$p['stock'] ?></td>
            <td><?= htmlspecialchars($p['categoria']) ?></td>
            <td><?php if (!empty($p['imagen'])): ?><img src="<?= htmlspecialchars($p['imagen']) ?>" alt="img" style="width:60px;height:40px;object-fit:cover"><?php endif; ?></td>
            <td>
              <a class="btn ghost" href="admin_panel.php?action=delete&id=<?= (int)$p['id_producto'] ?>" onclick="return confirm('¿Eliminar producto?')">Eliminar</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h2 class="section-title" style="margin-top:30px">Gestión de pedidos</h2>
    <table class="table">
      <thead>
        <tr>
          <th>ID</th><th>Usuario</th><th>Productos</th><th>Tipo</th><th>Total</th><th>Fecha</th><th>Estado</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($pedidos as $pd): ?>
          <tr>
            <td><?= (int)$pd['id_pedido'] ?></td>
            <td><?= htmlspecialchars($pd['username']) ?></td>
            <td style="max-width:360px;white-space:pre-wrap;"><?= htmlspecialchars($pd['productos']) ?></td>
            <td><?= htmlspecialchars($pd['tipo_pedido']) ?></td>
            <td>$<?= number_format((float)$pd['total'], 2) ?></td>
            <td><?= htmlspecialchars($pd['fecha_pedido']) ?></td>
            <td>
              <form method="post" action="update_pedido_estado.php">
                <input type="hidden" name="id_pedido" value="<?= (int)$pd['id_pedido'] ?>">
                <select name="estado" class="auth-input" style="padding:6px 8px">
                  <?php foreach (['Pendiente','En preparación','Listo','Entregado'] as $st): ?>
                    <option value="<?= $st ?>" <?= $pd['estado']===$st?'selected':'' ?>><?= $st ?></option>
                  <?php endforeach; ?>
                </select>
                <button class="btn primary" type="submit" style="margin-top:6px">Actualizar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>


